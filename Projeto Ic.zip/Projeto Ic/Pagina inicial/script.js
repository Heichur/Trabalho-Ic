let senha = ""; 

function definirSenha() {
  senha = prompt("Defina sua senha:");
}

function login() {
  const email = document.getElementById('emailInput').value;
  const senhaDigitada = document.getElementById('senhaInput').value;


  if (email.includes('flemingeducacao.com.br') && senhaDigitada === senha && senha.includes("020")) {
    document.getElementById('loginModal').style.display = 'none';
    document.getElementById('main-content').style.display = 'block';
    document.getElementById('mainHeader').style.display = 'flex';
  } else {
    alert("Senha ou email errados.");
  }
}
